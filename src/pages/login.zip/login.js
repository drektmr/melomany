import { NavLink,useNavigate} from 'react-router-dom';
import React, {useState, useContext, useReducer, useEffect} from "react";
import UserContext from "./context/UserContext";
function Login(){
    const navigation = useNavigate();
    const {userLogged,setUserLogged} = useContext(UserContext);
    const [email, setEmail] = useState();
    const [password, setPassword] = useState();
    const initialError = {email: "", password: ""};
    const [error, updateError] = useReducer(
        (error, updates) => ({
            ...error,
            ...updates,
        }),
        initialError
    );

    const handleSubmit = (e) => {
        e.preventDefault();
        [...e.target].map((element) => {
            if (element.type !== "submit") validation(element);
        })
        if (!error.email && !error.password) {
            fetch("http://192.168.25.4:8080/users/loginUser", {
                method: "post",
                mode: 'cors',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },body: JSON.stringify({
                    "email": email,
                    "password": password
                })
            })
                .then(response => response.json()
                )
                .then((user)=>{
                    if (user["email"]) {
                        setUserLogged(user);
                    }
                })
        }
    }
    const validation = (target) => {
        // Desestructuració de name, type i value de target
        let name = target.name;
        let value = target.value;
        let msg; // Variable on es desarà el missatge d'error
        //Comprova si té l'attribut required i té algun valor)
        if (name === "email" && !value) {
            msg = "Email is required"
        } else if (name === "password" && !value) {
            msg = "Password is required"
        } else {
            //debugger
            if (name === "email") {
                console.log(target.value);
                setEmail(value);

            } else if (name === "password") {
                console.log(target.value);
                setPassword(value);
                console.log(password);
            }
            msg = false;
        }
        updateError({[name]: msg});
    }
    return(
        <>
            {userLogged.length!==0?navigation("/", {replace: true}):""}
            <form className="form" onSubmit={handleSubmit} noValidate>
                <h2>LOGIN</h2>

                <p type="Email:"><input type="text" placeholder="Correo electrónico" name="email"></input></p>
                    <p className="red">{error.email}</p>
                <p type="Password:"><input type="password" placeholder="Escribe tu contraseña" name="password"></input></p>
                    <p className="red">{error.password}</p>
                <input name="sendLogin" type="submit" value={"Iniciar sesión"}/>
                <div>
                    <NavLink to="/register">No tienes una cuenta? Registrate </NavLink>
                </div>
            </form>
        </>
    )
}
export default Login;